#!/bin/bash

# Fail on any error, unset variable, or pipe failure
set -euo pipefail

# Define the zip and deb file names
ZIP_FILE="veracrypt-1.26.7-Ubuntu-22.04-amd64.zip"
DEB_FILE="veracrypt-1.26.7-Ubuntu-22.04-amd64.deb"

# Check if the zip file exists in the current directory
if [[ ! -f "$ZIP_FILE" ]]; then
  echo "Error: $ZIP_FILE not found in the current directory."
  exit 1
fi

# Extract the zip file
unzip "$ZIP_FILE"

# Check if the .deb file exists after extraction
if [[ ! -f "$DEB_FILE" ]]; then
  echo "Error: $DEB_FILE not found after extraction."
  exit 1
fi

# Install the .deb package
sudo apt install -y ./"$DEB_FILE"

# Check if VeraCrypt was installed successfully by checking its version
if veracrypt --version; then
  echo "VeraCrypt was installed successfully."
else
  echo "Error: VeraCrypt installation failed."
  exit 1
fi

